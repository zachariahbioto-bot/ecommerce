from django.db import models
from django.contrib.auth import get_user_model
from decimal import Decimal

User = get_user_model() 

# --- Product Model (Assuming this existed) ---
class Product(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image_url = models.URLField(max_length=200, default='http://example.com/default.jpg')
    category = models.CharField(max_length=100, default='Misc')
    
    def __str__(self):
        return self.name

# --- Cart Models (Assuming this existed) ---
class Cart(models.Model):
    session_key = models.CharField(max_length=40, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def get_cart_total(self) -> Decimal:
        # Sum of all cart item totals
        total = sum(item.get_total for item in self.cartitem_set.all())
        return Decimal(total)

    @property
    def get_cart_items_count(self) -> int:
        return self.cartitem_set.count()

    def __str__(self):
        return f'Cart {self.id}'

class CartItem(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    @property
    def get_total(self) -> Decimal:
        return self.product.price * self.quantity

    def __str__(self):
        return f'{self.product.name} ({self.quantity})'


# --- Order Models (The source of the FieldError) ---
class Order(models.Model):
    # Link to user (Step 5 addition)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Customer Information (The fields the form is failing on)
    full_name = models.CharField(max_length=255)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True)
    
    # Shipping Address (The fields the form is failing on)
    address = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    zipcode = models.CharField(max_length=20)
    
    # Financials
    cart = models.ForeignKey(Cart, on_delete=models.SET_NULL, null=True, related_name='orders')
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    order_date = models.DateTimeField(auto_now_add=True)
    
    # Statuses: P (Pending), C (Complete), S (Shipped), F (Failed)
    status = models.CharField(max_length=1, default='P')

    class Meta:
        ordering = ['-order_date']

    def __str__(self):
        return f'Order {self.id} by {self.full_name}'


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price_at_purchase = models.DecimalField(max_digits=10, decimal_places=2)

    def get_cost(self):
        return self.price_at_purchase * self.quantity

    def __str__(self):
        return f'{self.quantity} x {self.product.name} for Order {self.order.id}'
