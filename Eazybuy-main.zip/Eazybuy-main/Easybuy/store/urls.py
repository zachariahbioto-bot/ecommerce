from django.urls import path
from . import views # <-- THE MISSING IMPORT

urlpatterns = [
    path('', views.home, name='home'), # Assuming 'home' is your main view
    path('products/<int:pk>/', views.product_detail, name='product_detail'), # Assuming this exists
    path('add_to_cart/<int:pk>/', views.add_to_cart, name='add_to_cart'), # Assuming this exists
    path('cart/', views.cart_detail, name='cart_detail'),
    
    # Newly added cart management views
    path('cart/remove/<int:pk>/', views.remove_from_cart, name='remove_from_cart'),
    path('cart/update/<int:pk>/', views.update_cart_item, name='update_cart_item'),
    
    # Placeholder for the next step
    path('checkout/', views.checkout, name='checkout'), 
]

# ... existing paths ...
path('account/history/', views.order_history, name='order_history'),


from django.contrib.auth import views as auth_views # Import Django's built-in auth views
# ... existing imports

# --- Authentication Paths ---
urlpatterns += [
    # Login View (uses built-in form, looks for registration/login.html)
    path('login/', auth_views.LoginView.as_view(template_name='store/login.html'), name='login'),
    
    # Logout View (logs user out and redirects to home)
    path('logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
    
    # User Profile / Order History
    path('account/history/', views.order_history, name='order_history'),
]
