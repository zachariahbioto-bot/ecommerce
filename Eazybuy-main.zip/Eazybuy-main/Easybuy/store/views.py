from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpRequest, HttpResponse
from django.db import transaction
from django.contrib.auth.decorators import login_required
from .models import Product, Cart, CartItem, Order, OrderItem
from .forms import CheckoutForm
from decimal import Decimal

# Helper function to get cart info
def _get_cart_info(request):
    try:
        cart = Cart.objects.get(session_key=request.session.session_key)
        cart_items = CartItem.objects.filter(cart=cart)
        cart_total = cart.get_cart_total
        cart_items_count = cart_items.count()
    except Cart.DoesNotExist:
        cart = None
        cart_items = []
        cart_total = Decimal('0.00')
        cart_items_count = 0
    except Exception:
        # Graceful handling for non-existent session/key
        cart = None
        cart_items = []
        cart_total = Decimal('0.00')
        cart_items_count = 0
    return cart, cart_items, cart_total, cart_items_count

# --- Existing Views ---
def home(request: HttpRequest) -> HttpResponse:
    products = Product.objects.all() 
    cart, _, _, cart_items_count = _get_cart_info(request)
    context = {'products': products, 'cart_items_count': cart_items_count}
    return render(request, 'store/home.html', context)

def product_detail(request: HttpRequest, pk: int) -> HttpResponse:
    product = get_object_or_404(Product, pk=pk)
    cart, _, _, cart_items_count = _get_cart_info(request)
    return render(request, 'store/product_detail.html', {'product': product, 'cart_items_count': cart_items_count})
    
def add_to_cart(request: HttpRequest, pk: int) -> HttpResponse:
    # ... (Keep your previous add_to_cart implementation here)
    pass # Placeholder
    
def cart_detail(request: HttpRequest) -> HttpResponse:
    cart, cart_items, cart_total, cart_items_count = _get_cart_info(request)
    SHIPPING_COST = Decimal('15.00')
    grand_total = cart_total + SHIPPING_COST
    context = {
        'cart': cart, 
        'cart_items': cart_items, 
        'cart_total': cart_total, 
        'grand_total': grand_total,
        'cart_items_count': cart_items_count
    }
    return render(request, 'store/cart.html', context)

def remove_from_cart(request: HttpRequest, pk: int) -> HttpResponse:
    # ... (Keep your previous remove_from_cart implementation here)
    pass # Placeholder

def update_cart_item(request: HttpRequest, pk: int) -> HttpResponse:
    # ... (Keep your previous update_cart_item implementation here)
    pass # Placeholder

# --- MODIFIED Checkout View ---
def checkout(request: HttpRequest) -> HttpResponse:
    cart, cart_items, cart_total, cart_items_count = _get_cart_info(request)
    SHIPPING_COST = Decimal('15.00')
    grand_total = cart_total + SHIPPING_COST
    
    if not cart_items:
        return redirect('cart_detail')

    if request.method == 'POST':
        form = CheckoutForm(request.POST)
        
        if form.is_valid():
            try:
                with transaction.atomic():
                    # 🌟 1. Create the Order
                    order = form.save(commit=False)
                    order.cart = cart
                    order.total_amount = grand_total
                    
                    # 🌟 2. Link to Authenticated User
                    if request.user.is_authenticated:
                        order.user = request.user
                    
                    order.save()
                    
                    # 3. Create Order Items
                    for item in cart_items:
                        OrderItem.objects.create(
                            order=order,
                            product=item.product,
                            quantity=item.quantity,
                            price_at_purchase=item.product.price
                        )
                    
                    # 4. Clear the cart
                    cart_items.delete()
                    
                    # Success: Redirect to a confirmation or history page
                    return redirect('order_history') 

            except Exception as e:
                print(f"FATAL ORDER PROCESSING ERROR: {e}")
                # Log and return with error message
                context = {
                    'form': form, 'cart_total': cart_total, 'grand_total': grand_total, 
                    'error_message': 'Could not process order.',
                    'SHIPPING_COST': SHIPPING_COST, 'cart_items_count': cart_items_count
                }
                return render(request, 'store/checkout.html', context)
        
    else: # GET Request
        # �� Pre-populate form for logged-in users
        initial_data = {}
        if request.user.is_authenticated:
            initial_data = {
                'full_name': f"{request.user.first_name} {request.user.last_name}".strip(),
                'email': request.user.email,
            }
        
        form = CheckoutForm(initial=initial_data)

    context = {
        'form': form,
        'cart_total': cart_total,
        'grand_total': grand_total,
        'SHIPPING_COST': SHIPPING_COST,
        'cart_items_count': cart_items_count,
    }
    return render(request, 'store/checkout.html', context)


# --- Existing Order History View ---
from django.contrib.auth.models import User as DjangoUser
from django.db.models import Prefetch

@login_required
def order_history(request):
    """
    Displays all completed orders for the currently authenticated user.
    """
    orders = Order.objects.filter(
        user=request.user
    ).exclude(
        status__in=['P', 'F']
    ).prefetch_related(
        # Use Prefetch to efficiently load OrderItems and their related Products
        Prefetch('items', queryset=OrderItem.objects.select_related('product'))
    )
    
    context = {
        'orders': orders,
        'cart_items_count': _get_cart_info(request)[3] 
    }
    return render(request, 'store/order_history.html', context)
