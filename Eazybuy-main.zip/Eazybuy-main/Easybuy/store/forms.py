from django import forms
from .models import Order

class CheckoutForm(forms.ModelForm):
    """
    Form based on the Order model to capture customer and shipping details.
    """
    class Meta:
        model = Order
        fields = ['full_name', 'email', 'phone', 'address', 'city', 'zipcode']
        # Adding widgets for clean HTML/CSS integration
        widgets = {
            'full_name': forms.TextInput(attrs={'placeholder': 'Full Name', 'class': 'w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-brand-orange focus:border-brand-orange transition'}),
            'email': forms.EmailInput(attrs={'placeholder': 'Email Address', 'class': 'w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-brand-orange focus:border-brand-orange transition'}),
            'phone': forms.TextInput(attrs={'placeholder': 'Phone (Optional)', 'class': 'w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-brand-orange focus:border-brand-orange transition'}),
            'address': forms.TextInput(attrs={'placeholder': 'Street Address', 'class': 'w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-brand-orange focus:border-brand-orange transition'}),
            'city': forms.TextInput(attrs={'placeholder': 'City', 'class': 'w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-brand-orange focus:border-brand-orange transition'}),
            'zipcode': forms.TextInput(attrs={'placeholder': 'ZIP Code', 'class': 'w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-brand-orange focus:border-brand-orange transition'}),
        }
